package com.jash.files.data

import com.jash.files.util.Fmt
import com.jash.files.util.Intents
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileInputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URLEncoder
import java.security.SecureRandom

/** "View on PC": a small web server so a computer on the same Wi-Fi can browse, download and upload files. */
class PcServer(port: Int, private val root: File, val code: String) : NanoHTTPD(port) {

    companion object {
        const val PORT = 8686

        fun newCode(): String {
            val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            val r = SecureRandom()
            return (1..6).map { chars[r.nextInt(chars.length)] }.joinToString("")
        }

        fun localIp(): String? = runCatching {
            NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .sortedBy { if (it.name.startsWith("wlan")) 0 else if (it.name.startsWith("ap") || it.name.startsWith("swlan")) 1 else 2 }
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }
                ?.hostAddress
        }.getOrNull()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun html(status: Response.Status, body: String) =
        newFixedLengthResponse(status, "text/html; charset=utf-8", body)

    override fun serve(session: IHTTPSession): Response {
        val params = session.parameters
        val key = params["k"]?.firstOrNull()?.trim()?.uppercase()
        if (key != code) return html(Response.Status.FORBIDDEN, page("Jash Files", loginBody(key != null)))

        val rel = (params["p"]?.firstOrNull() ?: "").trim('/')
        val target = File(root, rel).canonicalFile
        val rootCanon = root.canonicalFile
        if (target != rootCanon && !target.path.startsWith(rootCanon.path + "/")) {
            return html(Response.Status.FORBIDDEN, page("Not allowed", "<p class='empty'>That location isn't shared.</p>"))
        }

        var message = ""
        if (session.method == Method.POST && target.isDirectory) {
            message = try {
                val files = HashMap<String, String>()
                session.parseBody(files)
                var n = 0
                for ((field, tmpPath) in files) {
                    if (!field.startsWith("file")) continue
                    val name = session.parameters[field]?.firstOrNull()?.substringAfterLast('/')?.substringAfterLast('\\')
                    if (name.isNullOrBlank()) continue
                    val dest = FileRepo.uniqueTarget(target, name, false)
                    File(tmpPath).copyTo(dest)
                    n++
                }
                if (n > 0) "Uploaded ${Fmt.plural(n, "file")}." else "Choose a file to upload."
            } catch (e: Exception) {
                "Upload failed: ${e.message ?: "unknown error"}"
            }
        }

        if (target.isFile) {
            val r = newFixedLengthResponse(Response.Status.OK, Intents.mime(target).let { if (it == "*/*") "application/octet-stream" else it }, FileInputStream(target), target.length())
            if (params["dl"]?.firstOrNull() == "1") r.addHeader("Content-Disposition", "attachment; filename=\"${target.name.replace("\"", "")}\"")
            return r
        }
        if (!target.isDirectory) return html(Response.Status.NOT_FOUND, page("Not found", "<p class='empty'>This item no longer exists.</p>"))
        return html(Response.Status.OK, page(if (rel.isEmpty()) "Internal Storage" else target.name, folderBody(rel, target, message)))
    }

    private fun link(rel: String, extra: String = "") = "?k=$code&p=${enc(rel)}$extra"

    private fun loginBody(wrong: Boolean) = """
        <div class="login">
          <div class="logo">📁</div>
          <h1>Jash Files</h1>
          <p>Enter the code shown on your phone.</p>
          <form method="get"><input name="k" maxlength="6" autocomplete="off" autofocus placeholder="ABC123" style="text-transform:uppercase">
          <button>Open</button></form>
          ${if (wrong) "<p class='err'>That code isn't right.</p>" else ""}
        </div>"""

    private fun folderBody(rel: String, dir: File, message: String): String {
        val sb = StringBuilder()
        // breadcrumbs
        sb.append("<nav class='crumbs'><a href='${link("")}'>Internal Storage</a>")
        var acc = ""
        rel.split('/').filter { it.isNotEmpty() }.forEach { part ->
            acc = if (acc.isEmpty()) part else "$acc/$part"
            sb.append(" <span>›</span> <a href='${link(acc)}'>${esc(part)}</a>")
        }
        sb.append("</nav>")
        sb.append("<h1>${esc(if (rel.isEmpty()) "Internal Storage" else dir.name)}</h1>")
        if (message.isNotEmpty()) sb.append("<p class='msg'>${esc(message)}</p>")
        sb.append(
            """<form class="up" method="post" enctype="multipart/form-data" action="${link(rel)}">
               <input type="file" name="file" multiple><button>Upload</button></form>"""
        )
        val kids = (dir.listFiles() ?: emptyArray())
            .filter { !it.name.startsWith(".") }
            .sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
        if (kids.isEmpty()) {
            sb.append("<p class='empty'>This folder is empty.</p>")
        } else {
            sb.append("<div class='list'>")
            for (f in kids) {
                val r = if (rel.isEmpty()) f.name else "$rel/${f.name}"
                val icon = if (f.isDirectory) "📁" else when (kindOf(f.extension.lowercase(), false)) {
                    FileKind.Image -> "🖼️"; FileKind.Video -> "🎬"; FileKind.Audio -> "🎵"; FileKind.Pdf -> "📕"
                    FileKind.Archive -> "🗜️"; FileKind.Apk -> "🤖"; FileKind.Sheet -> "📊"; FileKind.Slides -> "📽️"
                    else -> "📄"
                }
                val meta = if (f.isDirectory) Fmt.plural(f.list()?.size ?: 0, "item") else Fmt.size(f.length())
                sb.append("<div class='row'><a class='name' href='${link(r)}'><span class='ic'>$icon</span><span class='t'>${esc(f.name)}</span></a>")
                sb.append("<span class='meta'>${esc(meta)} · ${esc(Fmt.shortDate(f.lastModified()))}</span>")
                if (f.isFile) sb.append("<a class='dl' href='${link(r, "&dl=1")}'>Download</a>")
                sb.append("</div>")
            }
            sb.append("</div>")
        }
        return sb.toString()
    }

    private fun page(title: String, body: String) = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} · Jash Files</title>
<style>
:root{--bg:#f2f2f7;--card:#fff;--label:#000;--label2:rgba(60,60,67,.6);--sep:rgba(60,60,67,.18);--blue:#007aff;--red:#ff3b30}
@media(prefers-color-scheme:dark){:root{--bg:#000;--card:#1c1c1e;--label:#fff;--label2:rgba(235,235,245,.6);--sep:rgba(84,84,88,.6);--blue:#0a84ff;--red:#ff453a}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--label);font:16px -apple-system,system-ui,"Segoe UI",Roboto,sans-serif;padding:24px 16px}
.wrap{max-width:860px;margin:0 auto}a{color:var(--blue);text-decoration:none}
h1{font-size:34px;letter-spacing:.3px;margin:6px 0 16px}.crumbs{font-size:15px;color:var(--label2)}.crumbs span{margin:0 4px}
.up{display:flex;gap:10px;align-items:center;flex-wrap:wrap;background:var(--card);border-radius:12px;padding:12px 16px;margin-bottom:18px}
.up input{flex:1;min-width:0}button{background:var(--blue);color:#fff;border:0;border-radius:999px;padding:9px 18px;font:600 15px inherit;cursor:pointer}
.list{background:var(--card);border-radius:12px;overflow:hidden}.row{display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:.5px solid var(--sep)}
.row:last-child{border-bottom:0}.name{display:flex;align-items:center;gap:12px;flex:1;min-width:0;color:var(--label)}
.ic{font-size:24px}.t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.meta{color:var(--label2);font-size:13px;white-space:nowrap}
.dl{font-size:15px;white-space:nowrap}.empty{color:var(--label2);text-align:center;padding:40px}.msg{background:var(--card);border-radius:12px;padding:12px 16px}
.login{max-width:340px;margin:12vh auto;text-align:center}.logo{font-size:56px}.login input{width:100%;font:600 24px ui-monospace,monospace;text-align:center;padding:12px;border-radius:12px;border:1px solid var(--sep);background:var(--card);color:var(--label);margin:12px 0;letter-spacing:4px}
.login button{width:100%;padding:13px}.err{color:var(--red)}
@media(max-width:600px){.meta{display:none}}
</style></head><body><div class="wrap">$body</div></body></html>"""
}
