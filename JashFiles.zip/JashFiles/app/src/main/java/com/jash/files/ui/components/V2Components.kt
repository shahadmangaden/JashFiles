package com.jash.files.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jash.files.ui.theme.IOS
import com.jash.files.ui.theme.T

/** Two-tone colors for app-icon style tiles. */
data class Tint(val top: Color, val bottom: Color)

object Tints {
    val orange = Tint(Color(0xFFFFB340), Color(0xFFFF8A00))
    val teal = Tint(Color(0xFF5EE7DF), Color(0xFF16A9A0))
    val purple = Tint(Color(0xFFB98BFF), Color(0xFF7B3FE4))
    val green = Tint(Color(0xFF5BD878), Color(0xFF26A645))
    val yellow = Tint(Color(0xFFFFD84D), Color(0xFFF5A200))
    val blue = Tint(Color(0xFF5AA9FF), Color(0xFF2F6BFF))
    val indigo = Tint(Color(0xFF8C9CFF), Color(0xFF4F5BE8))
    val sky = Tint(Color(0xFF4DD0FF), Color(0xFF0A84FF))
    val mint = Tint(Color(0xFF6EE7B7), Color(0xFF10A37F))
    val coral = Tint(Color(0xFFFF9A8B), Color(0xFFFF4D6D))
    val red = Tint(Color(0xFFFF7A7A), Color(0xFFE5304B))
    val graphite = Tint(Color(0xFF9AA5B4), Color(0xFF545E6E))
    val violet = Tint(Color(0xFFC4B5FD), Color(0xFF7C5CE6))
    val amber = Tint(Color(0xFFFCD34D), Color(0xFFF59E0B))
}

/** An iOS app-icon style squircle with a gradient and a white glyph. */
@Composable
fun AppTile(icon: ImageVector, tint: Tint, size: Dp = 56.dp) {
    val shape = RoundedCornerShape(size * 0.27f)
    Box(
        Modifier
            .size(size)
            .shadow(3.dp, shape, ambientColor = tint.bottom, spotColor = tint.bottom)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(tint.top, tint.bottom))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(size * 0.52f))
    }
}

data class TileSpec(val label: String, val icon: ImageVector, val tint: Tint, val onClick: () -> Unit)

/** A rounded card holding tiles in a grid, like an iOS home-screen page. */
@Composable
fun TileGrid(tiles: List<TileSpec>, columns: Int = 3) {
    val c = IOS.colors
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(c.card)
            .padding(vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        tiles.chunked(columns).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { t ->
                    Column(
                        Modifier.weight(1f).pressScale(onClick = t.onClick),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        AppTile(t.icon, t.tint)
                        Spacer(Modifier.size(7.dp))
                        Text(
                            t.label, fontSize = 13.sp, color = c.label, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 4.dp),
                        )
                    }
                }
                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 22.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, style = T.title3, fontWeight = FontWeight.Bold, color = IOS.colors.label, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

/** Circular usage ring with the percentage in the middle. */
@Composable
fun UsageRing(fraction: Float, size: Dp = 54.dp, stroke: Dp = 6.dp) {
    val c = IOS.colors
    val f = fraction.coerceIn(0f, 1f)
    val color = when {
        f >= 0.9f -> c.red
        f >= 0.75f -> c.orange
        else -> c.blue
    }
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val s = stroke.toPx()
            val arcSize = Size(this.size.width - s, this.size.height - s)
            val topLeft = Offset(s / 2, s / 2)
            drawArc(c.fill, 0f, 360f, false, topLeft, arcSize, style = Stroke(s))
            drawArc(color, -90f, 360f * f, false, topLeft, arcSize, style = Stroke(s, cap = StrokeCap.Round))
        }
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${(f * 100).toInt()}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = c.label)
            Text("%", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = c.label2, modifier = Modifier.padding(bottom = 2.dp))
        }
    }
}

/** Shape for a row inside a grouped card drawn row by row in a LazyColumn. */
fun insetShape(index: Int, count: Int): Shape = when {
    count == 1 -> RoundedCornerShape(12.dp)
    index == 0 -> RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
    index == count - 1 -> RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)
    else -> RectangleShape
}

@Composable
fun Modifier.insetCard(index: Int, count: Int): Modifier =
    this.padding(horizontal = 16.dp).clip(insetShape(index, count)).background(IOS.colors.card)

/** A label + text field row for grouped forms. */
@Composable
fun IOSFieldRow(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    placeholder: String = "",
    password: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Text,
    divider: Boolean = true,
) {
    val c = IOS.colors
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 46.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (label.isNotEmpty()) {
                Text(label, style = T.body, color = c.label, modifier = Modifier.width(110.dp))
            }
            Box(Modifier.weight(1f).padding(vertical = 12.dp), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) Text(placeholder, style = T.body, color = c.label3, maxLines = 1)
                BasicTextField(
                    value = value,
                    onValueChange = onChange,
                    singleLine = true,
                    textStyle = T.body.copy(color = c.label),
                    cursorBrush = SolidColor(c.blue),
                    visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (password) KeyboardType.Password else keyboard,
                        autoCorrectEnabled = false,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        if (divider) Hairline(Modifier.padding(start = 16.dp))
    }
}

/** Large centered icon + title + text used at the top of feature screens. */
@Composable
fun FeatureHero(icon: ImageVector, tint: Tint, title: String, text: String) {
    val c = IOS.colors
    Column(
        Modifier.fillMaxWidth().padding(start = 32.dp, end = 32.dp, top = 8.dp, bottom = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AppTile(icon, tint, 76.dp)
        Spacer(Modifier.size(14.dp))
        Text(title, style = T.title2, color = c.label, textAlign = TextAlign.Center)
        Spacer(Modifier.size(6.dp))
        Text(text, style = T.subhead, color = c.label2, textAlign = TextAlign.Center)
    }
}

@Composable
fun SecondaryButton(text: String, color: Color? = null, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = IOS.colors
    Box(
        modifier
            .fillMaxWidth()
            .heightIn(min = 50.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(c.fill)
            .tap(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, style = T.headline, color = color ?: c.blue) }
}
