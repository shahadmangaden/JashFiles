package com.jash.files.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lan
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jash.files.data.RemoteEntry
import com.jash.files.data.Server
import com.jash.files.data.ServerType
import com.jash.files.ui.AppViewModel
import com.jash.files.ui.Route
import com.jash.files.ui.components.AppTile
import com.jash.files.ui.components.DocIcon
import com.jash.files.ui.components.FeatureHero
import com.jash.files.ui.components.Hairline
import com.jash.files.ui.components.IOSFieldRow
import com.jash.files.ui.components.IOSGroup
import com.jash.files.ui.components.IOSRow
import com.jash.files.ui.components.IOSScreen
import com.jash.files.ui.components.IOSSearchField
import com.jash.files.ui.components.NavIconButton
import com.jash.files.ui.components.NavTextButton
import com.jash.files.ui.components.SecondaryButton
import com.jash.files.ui.components.Tint
import com.jash.files.ui.components.Tints
import com.jash.files.ui.components.emptyItem
import com.jash.files.ui.components.insetCard
import com.jash.files.ui.components.loadingItem
import com.jash.files.ui.components.rowPress
import com.jash.files.ui.components.tap
import com.jash.files.ui.theme.IOS
import com.jash.files.ui.theme.T
import com.jash.files.util.Fmt

private fun ServerType.tint(): Tint = when (this) {
    ServerType.FTP -> Tints.sky
    ServerType.SMB -> Tints.mint
    ServerType.WEBDAV -> Tints.coral
}

private fun ServerType.icon() = when (this) {
    ServerType.FTP -> Icons.Rounded.Dns
    ServerType.SMB -> Icons.Rounded.Lan
    ServerType.WEBDAV -> Icons.Rounded.Cloud
}

private fun ServerType.blurb() = when (this) {
    ServerType.FTP -> "Connect to an FTP server, such as a router, a NAS or a computer running an FTP server app."
    ServerType.SMB -> "Open shared folders on Windows computers and NAS drives on your Wi-Fi network."
    ServerType.WEBDAV -> "Connect to Nextcloud, ownCloud, a NAS or any other WebDAV server."
}

// =====================================================================
// Saved servers
// =====================================================================

@Composable
fun ServersScreen(vm: AppViewModel, type: ServerType, depth: Int, backLabel: String) {
    val x = vm.x
    val c = IOS.colors
    val list = x.servers.filter { it.type == type }
    IOSScreen(
        title = type.title,
        listState = vm.listState("servers:${type.name}#$depth"),
        backLabel = backLabel,
        onBack = { vm.back() },
        actions = { NavIconButton(Icons.Rounded.Add) { vm.push(Route.ServerEdit(type, null)) } },
    ) {
        item(key = "hero") { FeatureHero(type.icon(), type.tint(), type.title, type.blurb()) }
        item(key = "list") {
            IOSGroup(header = if (list.isEmpty()) null else "Saved") {
                list.forEach { s ->
                    Column(Modifier.fillMaxWidth().rowPress(onClick = { x.openServer(s) }, onLongClick = { x.serverMenu(s) })) {
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 60.dp).padding(start = 16.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AppTile(type.icon(), type.tint(), 36.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f).padding(vertical = 9.dp)) {
                                Text(s.name, style = T.body, color = c.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.subtitle, style = T.footnote, color = c.label2, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Box(Modifier.size(42.dp).tap { x.serverMenu(s) }, contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.MoreHoriz, null, tint = c.label2, modifier = Modifier.size(22.dp))
                            }
                        }
                        Hairline(Modifier.padding(start = 64.dp))
                    }
                }
                IOSRow(
                    "Add ${type.title} Server",
                    icon = Icons.Rounded.Add,
                    titleColor = c.blue,
                    divider = false,
                    onClick = { vm.push(Route.ServerEdit(type, null)) },
                )
            }
        }
    }
}

// =====================================================================
// Add / edit server
// =====================================================================

@Composable
fun ServerEditScreen(vm: AppViewModel, type: ServerType, id: String?, depth: Int, backLabel: String) {
    val x = vm.x
    val c = IOS.colors
    val existing = remember(id) { id?.let { x.server(it) } }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var host by remember { mutableStateOf(existing?.host ?: "") }
    var port by remember { mutableStateOf(existing?.port?.takeIf { it > 0 }?.toString() ?: "") }
    var user by remember { mutableStateOf(existing?.user ?: "") }
    var pass by remember { mutableStateOf(existing?.pass ?: "") }
    var path by remember { mutableStateOf(existing?.path ?: "") }

    val canSave = when (type) {
        ServerType.WEBDAV -> path.isNotBlank()
        ServerType.SMB -> host.isNotBlank() && path.isNotBlank()
        ServerType.FTP -> host.isNotBlank()
    }

    fun save() {
        val s = Server(
            id = existing?.id ?: "",
            type = type,
            name = name.trim().ifEmpty {
                when (type) {
                    ServerType.WEBDAV -> path.trim().removePrefix("https://").removePrefix("http://").substringBefore('/')
                    ServerType.SMB -> "${path.trim()} on ${host.trim()}"
                    ServerType.FTP -> host.trim()
                }
            },
            host = host.trim(),
            port = port.trim().toIntOrNull() ?: 0,
            user = user.trim(),
            pass = pass,
            path = path.trim(),
        )
        val saved = x.saveServer(s)
        vm.back()
        if (existing == null) x.openServer(saved)
    }

    IOSScreen(
        title = if (existing == null) "New ${type.title} Server" else "Edit Server",
        listState = vm.listState("edit:${type.name}:$id#$depth"),
        backLabel = backLabel,
        onBack = { vm.back() },
        actions = { NavTextButton("Save", bold = true, enabled = canSave) { if (canSave) save() } },
    ) {
        item(key = "form") {
            Spacer(Modifier.height(6.dp))
            when (type) {
                ServerType.FTP -> {
                    IOSGroup(header = "Server") {
                        IOSFieldRow("Name", name, { name = it }, "Optional")
                        IOSFieldRow("Host", host, { host = it }, "192.168.1.10", keyboard = KeyboardType.Uri)
                        IOSFieldRow("Port", port, { port = it.filter(Char::isDigit) }, "21", keyboard = KeyboardType.Number)
                        IOSFieldRow("Folder", path, { path = it }, "Optional, e.g. /files", divider = false)
                    }
                    IOSGroup(header = "Sign In", footer = "Leave the username empty to sign in anonymously.") {
                        IOSFieldRow("Username", user, { user = it }, "anonymous")
                        IOSFieldRow("Password", pass, { pass = it }, "Optional", password = true, divider = false)
                    }
                }
                ServerType.SMB -> {
                    IOSGroup(header = "Computer", footer = "Use the computer's IP address (for example 192.168.1.20) and the name of the shared folder.") {
                        IOSFieldRow("Name", name, { name = it }, "Optional")
                        IOSFieldRow("Host", host, { host = it }, "192.168.1.20", keyboard = KeyboardType.Uri)
                        IOSFieldRow("Share", path, { path = it }, "Shared folder name", divider = false)
                    }
                    IOSGroup(header = "Sign In", footer = "Leave the username empty to connect as a guest. For a domain account, type DOMAIN\\user.") {
                        IOSFieldRow("Username", user, { user = it }, "Guest")
                        IOSFieldRow("Password", pass, { pass = it }, "Optional", password = true, divider = false)
                    }
                }
                ServerType.WEBDAV -> {
                    IOSGroup(header = "Server", footer = "Nextcloud example: https://cloud.example.com/remote.php/dav/files/USERNAME/") {
                        IOSFieldRow("Name", name, { name = it }, "Optional")
                        IOSFieldRow("URL", path, { path = it }, "https://…", keyboard = KeyboardType.Uri, divider = false)
                    }
                    IOSGroup(header = "Sign In") {
                        IOSFieldRow("Username", user, { user = it }, "Optional")
                        IOSFieldRow("Password", pass, { pass = it }, "Optional", password = true, divider = false)
                    }
                }
            }
        }
        if (existing != null) {
            item(key = "delete") {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    SecondaryButton("Delete Server", color = c.red) {
                        vm.alert = com.jash.files.ui.AlertSpec("Delete “${existing.name}”?", "Only the saved connection is removed.", confirm = "Delete", destructive = true) {
                            x.deleteServer(existing.id)
                            vm.back()
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// Remote folder browser
// =====================================================================

@Composable
fun RemoteScreen(vm: AppViewModel, serverId: String, path: String, title: String, depth: Int, backLabel: String) {
    val x = vm.x
    val c = IOS.colors
    val ctx = LocalContext.current
    val server = x.server(serverId)
    var query by remember(serverId, path) { mutableStateOf("") }
    val result by produceState<Result<List<RemoteEntry>>?>(null, serverId, path, x.remoteTick) {
        value = if (server == null) Result.failure(IllegalStateException("This server was removed.")) else runCatching { x.list(server, path) }
    }
    val shown = remember(result, query) {
        result?.getOrNull()?.let { l -> if (query.isBlank()) l else l.filter { it.name.contains(query, ignoreCase = true) } }
    }

    IOSScreen(
        title = title,
        listState = vm.listState("r:$serverId:$path#$depth"),
        plain = true,
        backLabel = backLabel,
        onBack = { vm.back() },
        actions = { if (server != null) NavIconButton(Icons.Rounded.MoreHoriz, circled = true) { x.remoteFolderMenu(server, path) } },
        header = { IOSSearchField(query, { query = it }) },
        bottomPadding = vm.overlayPadding,
    ) {
        val r = result
        when {
            r == null -> {
                item(key = "connecting") {
                    Text(
                        "Connecting to ${server?.name ?: "server"}…",
                        style = T.subhead, color = c.label2, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
                    )
                }
                loadingItem()
            }
            r.isFailure -> {
                emptyItem("Couldn't Connect", r.exceptionOrNull()?.message ?: "Something went wrong.")
                item(key = "retry") {
                    Column(Modifier.padding(horizontal = 32.dp)) {
                        SecondaryButton("Try Again") { x.refreshRemote() }
                        if (server != null) {
                            Spacer(Modifier.height(10.dp))
                            SecondaryButton("Edit Server") { vm.push(Route.ServerEdit(server.type, server.id)) }
                        }
                    }
                }
            }
            shown.isNullOrEmpty() -> emptyItem(if (query.isBlank()) "Folder Is Empty" else "No Results")
            else -> {
                val list = shown
                list.forEachIndexed { i, e ->
                    item(key = "e:" + e.path) {
                        Column(
                            Modifier.fillMaxWidth().rowPress(
                                onClick = { if (server != null) x.tapRemote(ctx, server, e) },
                                onLongClick = { if (server != null) x.remoteMenu(ctx, server, e) },
                            ),
                        ) {
                            Row(
                                Modifier.fillMaxWidth().heightIn(min = 62.dp).padding(start = 16.dp, end = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                if (e.isDir) Icon(Icons.Rounded.Folder, null, tint = c.folder, modifier = Modifier.size(42.dp))
                                else DocIcon(e.asItem(), 42.dp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f).padding(vertical = 9.dp)) {
                                    Text(e.name, style = T.body, color = c.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        (if (e.modified > 0) Fmt.date(e.modified) + "  ·  " else "") + if (e.isDir) "Folder" else Fmt.size(e.size),
                                        style = T.footnote, color = c.label2, maxLines = 1,
                                    )
                                }
                                Box(
                                    Modifier.size(42.dp).tap { if (server != null) x.remoteMenu(ctx, server, e) },
                                    contentAlignment = Alignment.Center,
                                ) { Icon(Icons.Rounded.MoreHoriz, null, tint = c.label2, modifier = Modifier.size(22.dp)) }
                            }
                            if (i < list.lastIndex) Hairline(Modifier.padding(start = 70.dp))
                        }
                    }
                }
                item(key = "__footer") {
                    Text(
                        Fmt.plural(list.size, "item") + " on ${server?.name ?: "server"}",
                        style = T.footnote, color = c.label2, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
                    )
                }
            }
        }
    }
}
