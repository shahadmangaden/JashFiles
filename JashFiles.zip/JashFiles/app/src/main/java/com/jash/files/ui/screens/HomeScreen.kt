package com.jash.files.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Lan
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.PieChart
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.SdStorage
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.jash.files.data.FileCategory
import com.jash.files.data.FileRepo
import com.jash.files.data.ServerType
import com.jash.files.ui.AppViewModel
import com.jash.files.ui.Route
import com.jash.files.ui.Tab
import com.jash.files.ui.components.AppTile
import com.jash.files.ui.components.IOSGroup
import com.jash.files.ui.components.IOSRow
import com.jash.files.ui.components.IOSScreen
import com.jash.files.ui.components.IOSSearchField
import com.jash.files.ui.components.NavIconButton
import com.jash.files.ui.components.NavTextButton
import com.jash.files.ui.components.SectionTitle
import com.jash.files.ui.components.TileGrid
import com.jash.files.ui.components.TileSpec
import com.jash.files.ui.components.Tints
import com.jash.files.ui.components.UsageRing
import com.jash.files.ui.components.emptyItem
import com.jash.files.ui.components.fileList
import com.jash.files.ui.components.loadingItem
import com.jash.files.ui.components.pressScale
import com.jash.files.ui.theme.IOS
import com.jash.files.ui.theme.T
import com.jash.files.util.Fmt
import java.io.File

/** The iOS-style main page. */
@Composable
fun HomeScreen(vm: AppViewModel) {
    val c = IOS.colors
    val ctx = LocalContext.current
    val btPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) vm.x.sendUrisBluetooth(ctx, ArrayList(uris))
    }
    val leading: (@Composable () -> Unit)? = if (vm.selecting) {
        { NavTextButton("Select All") { vm.selectAll(vm.searchResults.orEmpty().map { it.path }) } }
    } else null

    IOSScreen(
        title = "Jash Files",
        listState = vm.listState("home"),
        leading = leading,
        actions = {
            if (vm.selecting) NavTextButton("Done", bold = true) { vm.endSelection() }
            else NavIconButton(Icons.Rounded.MoreHoriz, circled = true) { vm.showViewMenu(withSort = false, withSelect = vm.searchResults != null) }
        },
        header = { IOSSearchField(vm.searchQuery, vm::search, "Search all files") },
        bottomPadding = vm.overlayPadding,
    ) {
        if (vm.searchQuery.isNotBlank()) {
            val r = vm.searchResults
            when {
                r == null -> loadingItem()
                r.isEmpty() -> emptyItem("No Results", "Nothing matches “${vm.searchQuery}”.")
                else -> {
                    item(key = "__rhdr") {
                        Text(
                            if (vm.searching) "Searching…" else Fmt.plural(r.size, "Result"),
                            style = T.footnote, color = c.label2,
                            modifier = Modifier.padding(start = 32.dp, top = 8.dp, bottom = 7.dp),
                        )
                    }
                    fileList(vm, r, inset = true)
                }
            }
            return@IOSScreen
        }

        item(key = "storage") { StorageCards(vm) }
        item(key = "analyzer") { AnalyzerCard(vm) }

        item(key = "cats") {
            SectionTitle("Categories")
            TileGrid(
                listOf(
                    TileSpec("Images", Icons.Rounded.Photo, Tints.orange) { vm.push(Route.Category(FileCategory.Images)) },
                    TileSpec("Videos", Icons.Rounded.Videocam, Tints.teal) { vm.push(Route.Category(FileCategory.Videos)) },
                    TileSpec("Audio", Icons.Rounded.MusicNote, Tints.purple) { vm.push(Route.Category(FileCategory.Audio)) },
                    TileSpec("APKs", Icons.Rounded.Android, Tints.green) { vm.push(Route.Category(FileCategory.Apps)) },
                    TileSpec("Documents", Icons.Rounded.Description, Tints.yellow) { vm.push(Route.Category(FileCategory.Documents)) },
                    TileSpec("Compressed", Icons.Rounded.FolderZip, Tints.blue) { vm.push(Route.Category(FileCategory.Archives)) },
                )
            )
        }

        item(key = "network") {
            SectionTitle("Network")
            TileGrid(
                listOf(
                    TileSpec("View on PC", Icons.Rounded.Computer, Tints.indigo) { vm.push(Route.PcShare) },
                    TileSpec("FTP", Icons.Rounded.Dns, Tints.sky) { vm.push(Route.Servers(ServerType.FTP)) },
                    TileSpec("LAN", Icons.Rounded.Lan, Tints.mint) { vm.push(Route.Servers(ServerType.SMB)) },
                    TileSpec("WebDAV", Icons.Rounded.Cloud, Tints.coral) { vm.push(Route.Servers(ServerType.WEBDAV)) },
                    TileSpec("Bluetooth", Icons.Rounded.Bluetooth, Tints.blue) { btPicker.launch(arrayOf("*/*")) },
                    TileSpec("Downloads", Icons.Rounded.Download, Tints.violet) {
                        vm.openFolder(File(vm.root, "Download").absolutePath)
                    },
                )
            )
        }

        item(key = "tools") {
            SectionTitle("Tools")
            TileGrid(
                listOf(
                    TileSpec("Recent", Icons.Rounded.Schedule, Tints.violet) { vm.selectTab(Tab.Recents) },
                    TileSpec("Recycle Bin", Icons.Rounded.Delete, Tints.red) { vm.push(Route.RecycleBin) },
                    TileSpec("Encrypted", Icons.Rounded.Lock, Tints.graphite) { vm.push(Route.Vault) },
                    TileSpec("Cleanup", Icons.Rounded.CleaningServices, Tints.green) { vm.push(Route.Cleanup) },
                    TileSpec("Analyzer", Icons.Rounded.PieChart, Tints.amber) { vm.selectTab(Tab.Storage) },
                    TileSpec("Internal", Icons.Rounded.PhoneAndroid, Tints.sky) { vm.openFolder(vm.root.absolutePath) },
                )
            )
        }

        item(key = "fav") {
            SectionTitle("Favorites") {
                NavTextButton("Add") {
                    vm.openFolder(vm.root.absolutePath)
                    vm.showHud("Open a folder, then ••• → Add to Favorites")
                }
            }
            IOSGroup {
                if (vm.favorites.isEmpty()) {
                    IOSRow("No Favorites", subtitle = "Tap ••• on any folder, then Add to Favorites.", titleColor = c.label2, divider = false)
                }
                vm.favorites.forEachIndexed { i, p ->
                    IOSRow(
                        File(p).name,
                        icon = Icons.Rounded.Folder,
                        iconTint = c.folder,
                        chevron = true,
                        divider = i < vm.favorites.lastIndex,
                        onLongClick = { vm.showFavoriteMenu(p) },
                        onClick = { vm.openFolder(p) },
                    )
                }
            }
        }
    }
}

@Composable
private fun StorageCards(vm: AppViewModel) {
    val volumes = remember(vm.refreshTick) {
        listOf(Triple("Internal Storage", vm.root, false)) + vm.volumes.map { Triple("SD Card", it, true) }
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        volumes.take(2).forEach { (title, dir, sd) ->
            val space = remember(dir, vm.refreshTick) { FileRepo.space(dir) }
            StorageCard(
                title = title,
                total = space.first,
                free = space.second,
                sd = sd,
                compact = volumes.size > 1,
                modifier = Modifier.weight(1f),
            ) { vm.openFolder(dir.absolutePath) }
        }
    }
}

@Composable
private fun StorageCard(
    title: String,
    total: Long,
    free: Long,
    sd: Boolean,
    compact: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val c = IOS.colors
    val used = (total - free).coerceAtLeast(0)
    val frac = if (total > 0) used.toFloat() / total else 0f
    Row(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(c.card)
            .pressScale(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        UsageRing(frac, if (compact) 50.dp else 58.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (sd) Icons.Rounded.SdStorage else Icons.Rounded.PhoneAndroid, null, tint = c.blue, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text(title, style = T.subhead, fontWeight = FontWeight.SemiBold, color = c.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(3.dp))
            Text(
                if (compact) "${Fmt.size(used)} / ${Fmt.size(total)}" else "${Fmt.size(used)} of ${Fmt.size(total)} used",
                style = T.footnote, color = c.label2, maxLines = 1,
            )
            if (!compact) {
                Text("${Fmt.size(free)} available", style = T.footnote, color = c.green, maxLines = 1)
            }
        }
        if (!compact) Icon(Icons.Rounded.ChevronRight, null, tint = c.label3, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun AnalyzerCard(vm: AppViewModel) {
    val c = IOS.colors
    Row(
        Modifier
            .padding(horizontal = 16.dp)
            .padding(top = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(c.card)
            .pressScale(onClick = { vm.selectTab(Tab.Storage) })
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppTile(Icons.Rounded.PieChart, Tints.amber, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Space Analyzer", style = T.headline, color = c.label)
            Text("See what's taking up space and clean it", style = T.footnote, color = c.label2, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.clip(RoundedCornerShape(50)).background(c.fill).pressScale(onClick = { vm.push(Route.Cleanup) })
                .padding(horizontal = 12.dp, vertical = 6.dp),
        ) {
            Text("Clean", style = T.subhead, fontWeight = FontWeight.SemiBold, color = c.blue)
        }
    }
}
