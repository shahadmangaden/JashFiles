package com.jash.files.ui

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.viewModelScope
import com.jash.files.data.Cleaner
import com.jash.files.data.FileRepo
import com.jash.files.data.JunkGroup
import com.jash.files.data.PcServer
import com.jash.files.data.RemoteEntry
import com.jash.files.data.RemoteFs
import com.jash.files.data.Server
import com.jash.files.data.Trash
import com.jash.files.data.TrashItem
import com.jash.files.data.Vault
import com.jash.files.data.VaultItem
import com.jash.files.data.downloadRecursive
import com.jash.files.data.uploadRecursive
import com.jash.files.util.Fmt
import com.jash.files.util.Intents
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** State and actions for the version 2 features. */
class Extras(private val vm: AppViewModel) {
    private val app: Application get() = vm.getApplication()
    private val scope get() = vm.viewModelScope

    private fun fail(e: Throwable) {
        vm.alert = AlertSpec("Couldn't Complete", e.message ?: "Something went wrong.", cancel = null)
    }

    /** Runs [block] on a background thread with a busy overlay. */
    private fun task(label: String, done: String?, after: () -> Unit = {}, block: suspend () -> Unit) {
        scope.launch {
            vm.busy = label
            try {
                block()
                done?.let { vm.showHud(it) }
                after()
            } catch (e: Exception) {
                fail(e)
            } finally {
                vm.busy = null
                vm.refresh()
            }
        }
    }

    // =================================================================
    // Recycle Bin
    // =================================================================

    var trash by mutableStateOf<List<TrashItem>?>(null); private set

    fun loadTrash() {
        scope.launch { trash = withContext(Dispatchers.IO) { Trash.items() } }
    }

    fun trashMenu(item: TrashItem) {
        vm.sheet = SheetSpec(
            header = item.asItem().copy(file = File(item.file.parentFile, item.name)),
            message = "From ${item.originalPath.substringBeforeLast('/')}",
            actions = listOf(
                SheetAction("Restore", Icons.Rounded.Restore) { restore(listOf(item)) },
                SheetAction("Delete Forever", Icons.Rounded.Delete, destructive = true) { deleteForever(listOf(item)) },
            ),
        )
    }

    fun restore(items: List<TrashItem>) {
        if (items.isEmpty()) return
        task("Restoring…", if (items.size == 1) "Restored" else "Restored ${items.size} items", after = { loadTrash() }) {
            withContext(Dispatchers.IO) { Trash.restore(items) }
        }
    }

    fun deleteForever(items: List<TrashItem>) {
        if (items.isEmpty()) return
        val t = if (items.size == 1) "Delete “${items[0].name}” Forever?" else "Delete ${items.size} Items Forever?"
        vm.alert = AlertSpec(t, "This can't be undone.", confirm = "Delete", destructive = true) {
            task("Deleting…", "Deleted", after = { loadTrash() }) { withContext(Dispatchers.IO) { Trash.deleteForever(items) } }
        }
    }

    fun emptyTrash() {
        vm.alert = AlertSpec("Empty Recycle Bin?", "All items in the Recycle Bin will be deleted forever.", confirm = "Empty", destructive = true) {
            task("Emptying…", "Recycle Bin Emptied", after = { loadTrash() }) { withContext(Dispatchers.IO) { Trash.empty() } }
        }
    }

    // =================================================================
    // Encrypted folder
    // =================================================================

    var vaultSetUp by mutableStateOf(Vault.isSetUp(vm.prefs)); private set
    var vaultUnlocked by mutableStateOf(Vault.isUnlocked); private set
    var vaultItems by mutableStateOf<List<VaultItem>?>(null); private set

    private val vaultOpenDir: File get() = File(app.cacheDir, "vault-open")

    fun createVault(password: String, confirm: String) {
        when {
            password.length < 4 -> vm.alert = AlertSpec("Password Too Short", "Use at least 4 characters.", cancel = null)
            password != confirm -> vm.alert = AlertSpec("Passwords Don't Match", "Type the same password twice.", cancel = null)
            else -> task("Creating…", "Encrypted Folder Ready", after = {
                vaultSetUp = true
                vaultUnlocked = true
                loadVault()
            }) { withContext(Dispatchers.Default) { Vault.setUp(vm.prefs, password) } }
        }
    }

    fun unlockVault(password: String) {
        scope.launch {
            vm.busy = "Unlocking…"
            val ok = try {
                withContext(Dispatchers.Default) { Vault.unlock(vm.prefs, password) }
            } catch (e: Exception) {
                false
            }
            vm.busy = null
            if (ok) {
                vaultUnlocked = true
                loadVault()
            } else {
                vm.alert = AlertSpec("Wrong Password", "Try again.", cancel = null)
            }
        }
    }

    fun lockVault(clearOpened: Boolean = true) {
        Vault.lock()
        vaultUnlocked = false
        vaultItems = null
        if (clearOpened) vaultOpenDir.deleteRecursively()
    }

    init {
        // Decrypted copies opened last time are removed when the app starts.
        runCatching { vaultOpenDir.deleteRecursively() }
    }

    fun loadVault() {
        if (!Vault.isUnlocked) return
        scope.launch {
            vaultItems = try {
                withContext(Dispatchers.IO) { Vault.items() }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    fun encryptFiles(files: List<File>) {
        if (files.isEmpty()) return
        if (!vaultSetUp || !Vault.isUnlocked) {
            vm.endSelection()
            vm.push(Route.Vault)
            vm.showHud(if (!vaultSetUp) "Create your Encrypted folder first" else "Unlock the Encrypted folder first")
            return
        }
        vm.endSelection()
        task("Encrypting…", "Moved to Encrypted Folder", after = { loadVault() }) {
            withContext(Dispatchers.IO) { Vault.addFiles(files) }
        }
    }

    /** Adds files picked with the system picker (the originals are kept). */
    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val cr = app.contentResolver
        task("Encrypting…", "Added ${Fmt.plural(uris.size, "file")}", after = { loadVault() }) {
            withContext(Dispatchers.IO) {
                for (u in uris) {
                    var name = "file"
                    cr.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) name = c.getString(0) ?: name
                    }
                    val path = File(File(FileRepo.root, "Download"), name).absolutePath
                    cr.openInputStream(u)?.use { Vault.addStream(it, path) }
                }
            }
        }
    }

    fun vaultMenu(ctx: Context, item: VaultItem) {
        vm.sheet = SheetSpec(
            header = item.asItem(),
            message = "Restores to ${item.originalPath.substringBeforeLast('/')}",
            actions = listOf(
                SheetAction("Open", Icons.Rounded.OpenInNew) { openVaultItem(ctx, item) },
                SheetAction("Restore (Decrypt)", Icons.Rounded.Restore) {
                    task("Decrypting…", "Restored", after = { loadVault() }) { withContext(Dispatchers.IO) { Vault.restore(item) } }
                },
                SheetAction("Delete Forever", Icons.Rounded.Delete, destructive = true) {
                    vm.alert = AlertSpec("Delete “${item.name}” Forever?", "This can't be undone.", confirm = "Delete", destructive = true) {
                        task("Deleting…", "Deleted", after = { loadVault() }) { withContext(Dispatchers.IO) { Vault.delete(listOf(item)) } }
                    }
                },
            ),
        )
    }

    private fun openVaultItem(ctx: Context, item: VaultItem) {
        task("Decrypting…", null, after = {}) {
            val out = File(vaultOpenDir, item.name)
            withContext(Dispatchers.IO) {
                vaultOpenDir.mkdirs()
                Vault.decryptTo(item, out)
            }
            vm.open(ctx, out, false)
        }
    }

    // =================================================================
    // Cleanup
    // =================================================================

    var junk by mutableStateOf<List<JunkGroup>?>(null); private set
    var scanning by mutableStateOf(false); private set
    val junkSelected = mutableStateListOf<String>()

    fun scanJunk() {
        if (scanning) return
        scanning = true
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { Cleaner.scan(app) }.getOrDefault(emptyList()) }
            junk = r
            junkSelected.clear()
            junkSelected.addAll(r.filter { it.autoClean }.map { it.id })
            scanning = false
        }
    }

    fun toggleJunk(id: String) {
        if (id in junkSelected) junkSelected.remove(id) else junkSelected.add(id)
    }

    fun cleanSelected() {
        val groups = junk?.filter { it.id in junkSelected }.orEmpty()
        if (groups.isEmpty()) return
        var freed = 0L
        task("Cleaning…", null, after = {
            vm.showHud("Freed ${Fmt.size(freed)}")
            junk = null
            scanJunk()
        }) { freed = withContext(Dispatchers.IO) { Cleaner.clean(groups) } }
    }

    fun maybeAutoClean(force: Boolean = false) {
        if (!vm.autoClean) return
        val now = System.currentTimeMillis()
        if (!force && now - vm.prefs.lastClean < 24L * 3600_000L) return
        vm.prefs.lastClean = now
        scope.launch {
            val freed = withContext(Dispatchers.IO) {
                runCatching { Cleaner.clean(Cleaner.scan(app).filter { it.autoClean }) }.getOrDefault(0L)
            }
            if (freed > 0) vm.showHud("Auto Cleanup freed ${Fmt.size(freed)}")
        }
    }

    // =================================================================
    // Bluetooth
    // =================================================================

    fun sendBluetooth(ctx: Context, files: List<File>) {
        val list = files.filter { it.isFile }
        if (list.isEmpty()) {
            vm.alert = AlertSpec("Can't Send Folders", "Compress the folder first, then send the ZIP file.", cancel = null)
            return
        }
        val uris = ArrayList(list.map { FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", it) })
        sendUrisBluetooth(ctx, uris)
    }

    fun sendUrisBluetooth(ctx: Context, uris: ArrayList<Uri>) {
        if (uris.isEmpty()) return
        val i = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        i.type = "*/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(Intent(i).setPackage("com.android.bluetooth"))
        } catch (e: ActivityNotFoundException) {
            try {
                ctx.startActivity(Intent.createChooser(i, "Send via Bluetooth").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
                fail(e2)
            }
        } catch (e: Exception) {
            fail(e)
        }
    }

    // =================================================================
    // View on PC
    // =================================================================

    var pcServer by mutableStateOf<PcServer?>(null); private set
    var pcAddress by mutableStateOf<String?>(null); private set

    fun startPc() {
        if (pcServer != null) return
        val ip = PcServer.localIp()
        if (ip == null) {
            vm.alert = AlertSpec("No Wi-Fi Connection", "Connect your phone to Wi-Fi (or turn on its hotspot), then try again.", cancel = null)
            return
        }
        try {
            val s = PcServer(PcServer.PORT, FileRepo.root, PcServer.newCode())
            s.start(fi.iki.elonen.NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            pcServer = s
            pcAddress = "http://$ip:${PcServer.PORT}"
        } catch (e: Exception) {
            fail(e)
        }
    }

    fun stopPc() {
        runCatching { pcServer?.stop() }
        pcServer = null
        pcAddress = null
    }

    // =================================================================
    // Servers: FTP, LAN (SMB), WebDAV
    // =================================================================

    var servers by mutableStateOf(vm.prefs.servers()); private set
    var remoteTick by mutableIntStateOf(0); private set

    private var fs: RemoteFs? = null
    private var fsId: String? = null
    private val mutex = Mutex()

    fun server(id: String): Server? = servers.firstOrNull { it.id == id }

    fun saveServer(s: Server): Server {
        val withId = if (s.id.isBlank()) s.copy(id = UUID.randomUUID().toString()) else s
        servers = servers.filter { it.id != withId.id } + withId
        vm.prefs.setServers(servers)
        if (fsId == withId.id) disconnect()
        return withId
    }

    fun deleteServer(id: String) {
        servers = servers.filter { it.id != id }
        vm.prefs.setServers(servers)
        if (fsId == id) disconnect()
    }

    fun serverMenu(s: Server) {
        vm.sheet = SheetSpec(
            title = s.name,
            message = s.subtitle,
            actions = listOf(
                SheetAction("Connect", Icons.Rounded.FolderOpen) { openServer(s) },
                SheetAction("Edit", Icons.Rounded.Edit) { vm.push(Route.ServerEdit(s.type, s.id)) },
                SheetAction("Delete", Icons.Rounded.Delete, destructive = true) {
                    vm.alert = AlertSpec("Delete “${s.name}”?", "Only the saved connection is removed.", confirm = "Delete", destructive = true) {
                        deleteServer(s.id)
                    }
                },
            ),
        )
    }

    fun openServer(s: Server) = vm.push(Route.Remote(s.id, "", s.name))

    fun chooseUploadServer(paths: List<String>) {
        vm.sheet = SheetSpec(
            title = "Upload to…",
            actions = servers.map { s ->
                SheetAction("${s.name} (${s.type.title})", Icons.Rounded.Storage) {
                    vm.setClip(paths, false)
                    openServer(s)
                }
            },
        )
    }

    private suspend fun <T> remote(server: Server, block: (RemoteFs) -> T): T = mutex.withLock {
        withContext(Dispatchers.IO) {
            val cur = fs
            val f = if (cur != null && fsId == server.id) {
                cur
            } else {
                runCatching { cur?.close() }
                fs = null
                fsId = null
                RemoteFs.open(server).also {
                    fs = it
                    fsId = server.id
                }
            }
            try {
                block(f)
            } catch (e: Exception) {
                runCatching { f.close() }
                fs = null
                fsId = null
                throw e
            }
        }
    }

    suspend fun list(server: Server, path: String): List<RemoteEntry> =
        remote(server) { it.list(path.ifEmpty { it.rootPath }) }

    fun refreshRemote() {
        remoteTick++
    }

    fun disconnect() {
        val f = fs
        fs = null
        fsId = null
        scope.launch(Dispatchers.IO) { runCatching { f?.close() } }
    }

    private fun remoteTask(label: String, done: String?, server: Server, block: (RemoteFs) -> Unit) {
        task(label, done, after = { remoteTick++ }) { remote(server, block) }
    }

    private val downloadDir: File get() = File(File(FileRepo.root, "Download"), "Jash Files")

    fun remoteMenu(ctx: Context, server: Server, e: RemoteEntry) {
        val a = mutableListOf<SheetAction>()
        if (e.isDir) a += SheetAction("Open", Icons.Rounded.FolderOpen) { vm.push(Route.Remote(server.id, e.path, e.name)) }
        else a += SheetAction("Open", Icons.Rounded.OpenInNew) { openRemote(ctx, server, e) }
        a += SheetAction("Download", Icons.Rounded.Download) { download(server, listOf(e)) }
        a += SheetAction("Delete", Icons.Rounded.Delete, destructive = true) {
            vm.alert = AlertSpec("Delete “${e.name}”?", "It will be deleted from the server. This can't be undone.", confirm = "Delete", destructive = true) {
                remoteTask("Deleting…", "Deleted", server) { it.delete(e) }
            }
        }
        vm.sheet = SheetSpec(header = e.asItem(), actions = a)
    }

    fun remoteFolderMenu(server: Server, path: String) {
        val a = mutableListOf<SheetAction>()
        a += SheetAction("New Folder", Icons.Rounded.CreateNewFolder) {
            vm.alert = AlertSpec("New Folder", "Enter a name for this folder.", input = "untitled folder", confirm = "Create") { n ->
                val name = n.trim().ifEmpty { "untitled folder" }.replace("/", "-")
                remoteTask("Creating…", null, server) { it.mkdir(path.ifEmpty { it.rootPath }, name) }
            }
        }
        a += SheetAction("Refresh", Icons.Rounded.Refresh) { remoteTick++ }
        a += SheetAction("Disconnect", Icons.Rounded.LinkOff, destructive = true) {
            disconnect()
            while (vm.stack.lastOrNull() is Route.Remote) vm.back()
        }
        vm.sheet = SheetSpec(title = server.name, message = "Tip: copy files on your phone, then open a folder here and tap Upload.", actions = a)
    }

    fun tapRemote(ctx: Context, server: Server, e: RemoteEntry) {
        if (e.isDir) vm.push(Route.Remote(server.id, e.path, e.name)) else remoteMenu(ctx, server, e)
    }

    fun openRemote(ctx: Context, server: Server, e: RemoteEntry) {
        val dir = File(app.cacheDir, "remote-open")
        var out: File? = null
        task("Downloading…", null, after = { out?.let { vm.open(ctx, it, false) } }) {
            remote(server) {
                dir.mkdirs()
                val t = File(dir, e.name)
                it.download(e, t)
                out = t
            }
        }
    }

    fun download(server: Server, entries: List<RemoteEntry>) {
        remoteTask("Downloading…", "Saved to Download/Jash Files", server) { f ->
            downloadDir.mkdirs()
            entries.forEach { f.downloadRecursive(it, downloadDir) }
        }
    }

    fun uploadHere(server: Server, path: String) {
        val clip = vm.takeClip() ?: return
        val files = clip.paths.map(::File).filter { it.exists() }
        remoteTask("Uploading…", "Uploaded ${Fmt.plural(files.size, "item")}", server) { f ->
            val dir = path.ifEmpty { f.rootPath }
            files.forEach { f.uploadRecursive(it, dir) }
        }
    }

    fun shutdown() {
        stopPc()
        runCatching { fs?.close() }
        fs = null
        Vault.lock()
    }
}
