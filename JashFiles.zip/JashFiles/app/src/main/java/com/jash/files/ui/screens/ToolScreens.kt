package com.jash.files.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jash.files.ui.AppViewModel
import com.jash.files.ui.components.FeatureHero
import com.jash.files.ui.components.FileIcon
import com.jash.files.ui.components.Hairline
import com.jash.files.ui.components.IOSFieldRow
import com.jash.files.ui.components.IOSGroup
import com.jash.files.ui.components.IOSRow
import com.jash.files.ui.components.IOSScreen
import com.jash.files.ui.components.IOSSwitch
import com.jash.files.ui.components.NavTextButton
import com.jash.files.ui.components.PrimaryButton
import com.jash.files.ui.components.SecondaryButton
import com.jash.files.ui.components.SelectCircle
import com.jash.files.ui.components.Tints
import com.jash.files.ui.components.emptyItem
import com.jash.files.ui.components.insetCard
import com.jash.files.ui.components.loadingItem
import com.jash.files.ui.components.rowPress
import com.jash.files.ui.components.tap
import com.jash.files.ui.theme.IOS
import com.jash.files.ui.theme.T
import com.jash.files.util.Fmt

/** A file-like row used inside inset cards. */
@Composable
private fun ItemRow(
    item: com.jash.files.data.FileItem,
    title: String,
    subtitle: String,
    index: Int,
    count: Int,
    onClick: () -> Unit,
) {
    val c = IOS.colors
    Column(Modifier.insetCard(index, count).rowPress(onClick = onClick)) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 62.dp).padding(start = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FileIcon(item, 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).padding(vertical = 9.dp)) {
                Text(title, style = T.body, color = c.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = T.footnote, color = c.label2, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.size(42.dp).tap(onClick = onClick), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.MoreHoriz, null, tint = c.label2, modifier = Modifier.size(22.dp))
            }
        }
        if (index < count - 1) Hairline(Modifier.padding(start = 70.dp))
    }
}

// =====================================================================
// Recycle Bin
// =====================================================================

@Composable
fun RecycleBinScreen(vm: AppViewModel, depth: Int, backLabel: String) {
    val x = vm.x
    val c = IOS.colors
    LaunchedEffect(vm.refreshTick) { x.loadTrash() }
    val items = x.trash
    IOSScreen(
        title = "Recycle Bin",
        listState = vm.listState("trash#$depth"),
        backLabel = backLabel,
        onBack = { vm.back() },
        actions = { if (!items.isNullOrEmpty()) NavTextButton("Empty", color = c.red) { x.emptyTrash() } },
    ) {
        when {
            items == null -> loadingItem()
            items.isEmpty() -> {
                item(key = "hero") {
                    FeatureHero(Icons.Rounded.Delete, Tints.red, "Recycle Bin Is Empty", "Deleted files stay here so you can restore them. Empty the bin to free up space.")
                }
            }
            else -> {
                item(key = "hdr") {
                    Text(
                        "${Fmt.plural(items.size, "item")} · Tap an item to restore it",
                        style = T.footnote, color = c.label2,
                        modifier = Modifier.padding(start = 32.dp, top = 6.dp, bottom = 7.dp),
                    )
                }
                items.forEachIndexed { i, t ->
                    item(key = t.file.absolutePath) {
                        ItemRow(
                            item = t.asItem(),
                            title = t.name,
                            subtitle = "Deleted ${Fmt.date(t.deletedAt)} · from ${t.originalPath.substringBeforeLast('/').substringAfterLast('/')}",
                            index = i,
                            count = items.size,
                        ) { x.trashMenu(t) }
                    }
                }
                item(key = "restoreAll") {
                    Column(Modifier.padding(16.dp)) {
                        Spacer(Modifier.height(8.dp))
                        SecondaryButton("Restore All") { x.restore(items) }
                    }
                }
            }
        }
    }
}

// =====================================================================
// Encrypted folder
// =====================================================================

@Composable
fun VaultScreen(vm: AppViewModel, depth: Int, backLabel: String) {
    val x = vm.x
    val c = IOS.colors
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        x.importUris(uris)
    }
    DisposableEffect(Unit) { onDispose { x.lockVault(clearOpened = false) } }
    LaunchedEffect(x.vaultUnlocked, vm.refreshTick) { if (x.vaultUnlocked) x.loadVault() }

    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }

    IOSScreen(
        title = "Encrypted",
        listState = vm.listState("vault#$depth"),
        backLabel = backLabel,
        onBack = { vm.back() },
        actions = { if (x.vaultUnlocked) NavTextButton("Lock") { x.lockVault() } },
    ) {
        when {
            !x.vaultSetUp -> {
                item(key = "hero") {
                    FeatureHero(Icons.Rounded.Lock, Tints.graphite, "Encrypted Folder", "Files you move here are locked with AES-256 encryption and a password only you know.")
                }
                item(key = "form") {
                    IOSGroup(footer = "If you forget this password, your encrypted files can't be recovered.") {
                        IOSFieldRow("Password", pw, { pw = it }, "Required", password = true)
                        IOSFieldRow("Confirm", pw2, { pw2 = it }, "Type it again", password = true, divider = false)
                    }
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        PrimaryButton("Create Encrypted Folder") {
                            x.createVault(pw, pw2)
                            pw = ""
                            pw2 = ""
                        }
                    }
                }
            }
            !x.vaultUnlocked -> {
                item(key = "hero") {
                    FeatureHero(Icons.Rounded.Lock, Tints.graphite, "Locked", "Enter your password to see your encrypted files.")
                }
                item(key = "form") {
                    IOSGroup {
                        IOSFieldRow("", pw, { pw = it }, "Password", password = true, divider = false)
                    }
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        PrimaryButton("Unlock") {
                            x.unlockVault(pw)
                            pw = ""
                        }
                    }
                }
            }
            else -> {
                val items = x.vaultItems
                item(key = "add") {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        SecondaryButton("Add Files from Phone…") { picker.launch(arrayOf("*/*")) }
                    }
                }
                when {
                    items == null -> loadingItem()
                    items.isEmpty() -> emptyItem(
                        "No Encrypted Files",
                        "Tap ••• on any file and choose Move to Encrypted Folder, or add files above.",
                    )
                    else -> {
                        item(key = "hdr") {
                            Text(
                                Fmt.plural(items.size, "file") + " · encrypted with AES-256",
                                style = T.footnote, color = c.label2,
                                modifier = Modifier.padding(start = 32.dp, top = 10.dp, bottom = 7.dp),
                            )
                        }
                        items.forEachIndexed { i, v ->
                            item(key = v.file.absolutePath) {
                                ItemRow(
                                    item = v.asItem(),
                                    title = v.name,
                                    subtitle = "${Fmt.size(v.size)} · added ${Fmt.shortDate(v.added)}",
                                    index = i,
                                    count = items.size,
                                ) { x.vaultMenu(ctx, v) }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// Cleanup
// =====================================================================

@Composable
fun CleanupScreen(vm: AppViewModel, depth: Int, backLabel: String) {
    val x = vm.x
    val c = IOS.colors
    LaunchedEffect(Unit) { if (x.junk == null) x.scanJunk() }
    val groups = x.junk
    val selectedSize = groups.orEmpty().filter { it.id in x.junkSelected }.sumOf { it.size }

    IOSScreen(
        title = "Cleanup",
        listState = vm.listState("cleanup#$depth"),
        backLabel = backLabel,
        onBack = { vm.back() },
        actions = { NavTextButton("Rescan", enabled = !x.scanning) { x.scanJunk() } },
    ) {
        item(key = "auto") {
            Spacer(Modifier.height(6.dp))
            IOSGroup(footer = "Once a day, when you open Jash Files, thumbnails, temporary files, the app cache and empty folders are cleaned. Installation files are never removed automatically.") {
                IOSRow(
                    "Auto Cleanup",
                    icon = Icons.Rounded.CleaningServices,
                    iconBg = c.green,
                    divider = false,
                    trailing = { IOSSwitch(vm.autoClean) { vm.toggleAutoClean() } },
                )
            }
        }
        when {
            groups == null || x.scanning -> {
                item(key = "scan") {
                    Text("Scanning your storage…", style = T.subhead, color = c.label2, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                }
                loadingItem()
            }
            groups.isEmpty() -> item(key = "clean") {
                FeatureHero(Icons.Rounded.CleaningServices, Tints.green, "All Clean", "No junk files were found.")
            }
            else -> {
                item(key = "junk") {
                    IOSGroup(header = "Found") {
                        groups.forEachIndexed { i, g ->
                            val sel = g.id in x.junkSelected
                            Column(Modifier.fillMaxWidth().rowPress(onClick = { x.toggleJunk(g.id) })) {
                                Row(
                                    Modifier.fillMaxWidth().heightIn(min = 60.dp).padding(horizontal = 16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    SelectCircle(sel)
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f).padding(vertical = 9.dp)) {
                                        Text(g.title, style = T.body, color = c.label)
                                        Text("${g.subtitle} · ${Fmt.plural(g.files.size, "item")}", style = T.footnote, color = c.label2, maxLines = 2)
                                    }
                                    Text(if (g.size > 0) Fmt.size(g.size) else "—", style = T.body, color = c.label2)
                                }
                                if (i < groups.lastIndex) Hairline(Modifier.padding(start = 53.dp))
                            }
                        }
                    }
                }
                item(key = "btn") {
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        PrimaryButton(if (x.junkSelected.isEmpty()) "Select Items to Clean" else "Clean Up ${Fmt.size(selectedSize)}") {
                            if (x.junkSelected.isNotEmpty()) {
                                vm.alert = com.jash.files.ui.AlertSpec(
                                    "Clean Up ${Fmt.size(selectedSize)}?",
                                    "The selected items will be deleted permanently.",
                                    confirm = "Clean Up",
                                    destructive = true,
                                ) { x.cleanSelected() }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// View on PC
// =====================================================================

@Composable
fun PcShareScreen(vm: AppViewModel, depth: Int, backLabel: String) {
    val x = vm.x
    val c = IOS.colors
    val clipboard = LocalClipboardManager.current
    val server = x.pcServer
    val address = x.pcAddress

    IOSScreen(
        title = "View on PC",
        listState = vm.listState("pc#$depth"),
        backLabel = backLabel,
        onBack = { vm.back() },
    ) {
        item(key = "hero") {
            FeatureHero(
                Icons.Rounded.Computer, Tints.indigo,
                if (server != null) "Ready" else "View on PC",
                if (server != null) "Your files can now be opened in a web browser on any computer on this Wi-Fi."
                else "Browse, download and upload your phone's files from a computer's web browser — no cable or app needed.",
            )
        }
        if (server != null && address != null) {
            item(key = "addr") {
                Column(
                    Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(c.card)
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(c.green))
                        Spacer(Modifier.width(6.dp))
                        Text("Running", style = T.footnote, fontWeight = FontWeight.SemiBold, color = c.green)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Type this in your computer's browser", style = T.footnote, color = c.label2)
                    Spacer(Modifier.height(4.dp))
                    Text(address, fontFamily = FontFamily.Monospace, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = c.blue, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Text("Access code", style = T.footnote, color = c.label2)
                    Spacer(Modifier.height(4.dp))
                    Text(server.code, fontFamily = FontFamily.Monospace, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp, color = c.label)
                    Spacer(Modifier.height(16.dp))
                    SecondaryButton("Copy Address") {
                        clipboard.setText(AnnotatedString("$address/?k=${server.code}"))
                        vm.showHud("Address Copied")
                    }
                }
            }
            item(key = "stop") {
                Column(Modifier.padding(16.dp)) {
                    SecondaryButton("Stop Sharing", color = c.red) { x.stopPc() }
                }
            }
        } else {
            item(key = "steps") {
                IOSGroup(header = "How it works") {
                    IOSRow("1. Connect both to the same Wi-Fi", subtitle = "Or turn on your phone's hotspot and join it from the PC.")
                    IOSRow("2. Tap Start below", subtitle = "Jash Files shows a web address and a code.")
                    IOSRow("3. Open the address on your PC", subtitle = "Enter the code, then browse, download or upload.", divider = false)
                }
                Box(Modifier.padding(horizontal = 16.dp)) {
                    PrimaryButton("Start") { x.startPc() }
                }
            }
        }
        item(key = "note") {
            Text(
                "Keep Jash Files open while you use it. Anyone on the same network who has the code can see your files, so stop sharing when you're done.",
                style = T.footnote, color = c.label2, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 12.dp),
            )
        }
    }
}
