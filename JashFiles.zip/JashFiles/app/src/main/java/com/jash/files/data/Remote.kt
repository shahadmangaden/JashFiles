package com.jash.files.data

import android.net.Uri
import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.msfscc.FileAttributes
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.security.bc.BCSecurityProvider
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.SmbConfig
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.connection.Connection
import com.hierynomus.smbj.session.Session
import com.hierynomus.smbj.share.DiskShare
import okhttp3.Credentials
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPReply
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.EnumSet
import java.util.Locale
import java.util.concurrent.TimeUnit

/** A connected remote file system. All calls block: use Dispatchers.IO. */
interface RemoteFs : Closeable {
    val rootPath: String
    fun list(path: String): List<RemoteEntry>
    fun child(dir: String, name: String): String
    fun download(entry: RemoteEntry, dest: File)
    fun uploadFile(local: File, dir: String)
    fun mkdir(dir: String, name: String): String
    fun delete(entry: RemoteEntry)

    companion object {
        fun open(s: Server): RemoteFs = when (s.type) {
            ServerType.FTP -> FtpFs(s)
            ServerType.SMB -> SmbFs(s)
            ServerType.WEBDAV -> DavFs(s)
        }
    }
}

fun RemoteFs.uploadRecursive(local: File, dir: String) {
    if (local.isDirectory) {
        val d = mkdir(dir, local.name)
        local.listFiles()?.forEach { uploadRecursive(it, d) }
    } else {
        uploadFile(local, dir)
    }
}

fun RemoteFs.downloadRecursive(e: RemoteEntry, destDir: File): File {
    return if (e.isDir) {
        val d = FileRepo.uniqueTarget(destDir, e.name, true)
        d.mkdirs()
        list(e.path).forEach { downloadRecursive(it, d) }
        d
    } else {
        val t = FileRepo.uniqueTarget(destDir, e.name, false)
        download(e, t)
        t
    }
}

fun sortRemote(list: List<RemoteEntry>): List<RemoteEntry> =
    list.sortedWith(compareByDescending<RemoteEntry> { it.isDir }.thenBy { it.name.lowercase() })

// ---------------- FTP ----------------

class FtpFs(s: Server) : RemoteFs {
    private val c = FTPClient()
    override val rootPath: String

    init {
        c.connectTimeout = 15_000
        c.controlEncoding = "UTF-8"
        try {
            c.connect(s.host.trim(), if (s.port > 0) s.port else 21)
        } catch (e: Exception) {
            throw IOException("Couldn't reach ${s.host}. Check the address and that you're on the same network.")
        }
        if (!FTPReply.isPositiveCompletion(c.replyCode)) {
            runCatching { c.disconnect() }
            throw IOException("The FTP server refused the connection.")
        }
        c.soTimeout = 30_000
        val anon = s.user.isBlank()
        if (!c.login(if (anon) "anonymous" else s.user, if (anon) "guest@" else s.pass)) {
            runCatching { c.disconnect() }
            throw IOException("Wrong username or password.")
        }
        c.enterLocalPassiveMode()
        c.setFileType(FTP.BINARY_FILE_TYPE)
        rootPath = s.path.trim().ifBlank { c.printWorkingDirectory() ?: "/" }
    }

    override fun child(dir: String, name: String) = if (dir.endsWith("/")) dir + name else "$dir/$name"

    override fun list(path: String): List<RemoteEntry> =
        sortRemote(c.listFiles(path).filterNotNull().filter { it.name != "." && it.name != ".." }.map {
            RemoteEntry(it.name, child(path, it.name), it.isDirectory, it.size, it.timestamp?.timeInMillis ?: 0L)
        })

    override fun download(entry: RemoteEntry, dest: File) {
        FileOutputStream(dest).use { if (!c.retrieveFile(entry.path, it)) throw IOException("Couldn't download “${entry.name}”.") }
    }

    override fun uploadFile(local: File, dir: String) {
        local.inputStream().use { if (!c.storeFile(child(dir, local.name), it)) throw IOException("Couldn't upload “${local.name}”.") }
    }

    override fun mkdir(dir: String, name: String): String {
        val p = child(dir, name)
        if (!c.makeDirectory(p)) throw IOException("Couldn't create “$name”.")
        return p
    }

    override fun delete(entry: RemoteEntry) {
        if (entry.isDir) {
            list(entry.path).forEach { delete(it) }
            if (!c.removeDirectory(entry.path)) throw IOException("Couldn't delete “${entry.name}”.")
        } else if (!c.deleteFile(entry.path)) {
            throw IOException("Couldn't delete “${entry.name}”.")
        }
    }

    override fun close() {
        runCatching { c.logout() }
        runCatching { c.disconnect() }
    }
}

// ---------------- LAN (SMB) ----------------

class SmbFs(s: Server) : RemoteFs {
    private val client = SMBClient(
        SmbConfig.builder()
            .withSecurityProvider(BCSecurityProvider())
            .withTimeout(20, TimeUnit.SECONDS)
            .build()
    )
    private val conn: Connection
    private val session: Session
    private val share: DiskShare
    override val rootPath: String = ""

    init {
        try {
            conn = if (s.port > 0 && s.port != 445) client.connect(s.host.trim(), s.port) else client.connect(s.host.trim())
        } catch (e: Exception) {
            client.close()
            throw IOException("Couldn't reach ${s.host}. Check the address and that you're on the same Wi-Fi.")
        }
        val auth = if (s.user.isBlank()) {
            AuthenticationContext.guest()
        } else {
            val domain = if ('\\' in s.user) s.user.substringBefore('\\') else ""
            val user = s.user.substringAfter('\\')
            AuthenticationContext(user, s.pass.toCharArray(), domain)
        }
        try {
            session = conn.authenticate(auth)
        } catch (e: Exception) {
            runCatching { conn.close() }
            client.close()
            throw IOException("Wrong username or password.")
        }
        val shareName = s.path.trim().trim('/', '\\')
        val sh = try {
            session.connectShare(shareName)
        } catch (e: Exception) {
            runCatching { session.close() }
            runCatching { conn.close() }
            client.close()
            throw IOException("Couldn't open the shared folder “$shareName”.")
        }
        share = sh as? DiskShare ?: throw IOException("“$shareName” isn't a shared folder.")
    }

    override fun child(dir: String, name: String) = if (dir.isEmpty()) name else "$dir\\$name"

    override fun list(path: String): List<RemoteEntry> =
        sortRemote(share.list(path).filter { it.fileName != "." && it.fileName != ".." }.map {
            RemoteEntry(
                name = it.fileName,
                path = child(path, it.fileName),
                isDir = (it.fileAttributes and FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value) != 0L,
                size = it.endOfFile,
                modified = it.lastWriteTime.toEpochMillis(),
            )
        })

    override fun download(entry: RemoteEntry, dest: File) {
        share.openFile(
            entry.path, EnumSet.of(AccessMask.GENERIC_READ), null,
            SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OPEN, null,
        ).use { f -> f.inputStream.use { ins -> FileOutputStream(dest).use { ins.copyTo(it, 64 * 1024) } } }
    }

    override fun uploadFile(local: File, dir: String) {
        share.openFile(
            child(dir, local.name), EnumSet.of(AccessMask.GENERIC_WRITE), null,
            SMB2ShareAccess.ALL, SMB2CreateDisposition.FILE_OVERWRITE_IF, null,
        ).use { f -> f.outputStream.use { out -> local.inputStream().use { it.copyTo(out, 64 * 1024) } } }
    }

    override fun mkdir(dir: String, name: String): String {
        val p = child(dir, name)
        share.mkdir(p)
        return p
    }

    override fun delete(entry: RemoteEntry) {
        if (entry.isDir) share.rmdir(entry.path, true) else share.rm(entry.path)
    }

    override fun close() {
        runCatching { share.close() }
        runCatching { session.close() }
        runCatching { conn.close() }
        runCatching { client.close() }
    }
}

// ---------------- WebDAV ----------------

class DavFs(s: Server) : RemoteFs {
    private val base: HttpUrl
    private val origin: String
    private val auth: String? = if (s.user.isBlank()) null else Credentials.basic(s.user, s.pass)
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()
    override val rootPath: String

    init {
        var u = s.path.trim()
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        if (!u.endsWith("/")) u += "/"
        base = try {
            u.toHttpUrl()
        } catch (e: Exception) {
            throw IOException("“${s.path}” isn't a valid web address.")
        }
        origin = base.scheme + "://" + base.host +
            (if (base.port != HttpUrl.defaultPort(base.scheme)) ":${base.port}" else "")
        rootPath = base.encodedPath
        list(rootPath) // checks address and login
    }

    private fun req(path: String) = Request.Builder().url(origin + path).apply { auth?.let { header("Authorization", it) } }

    private fun exec(r: Request): Response {
        val resp = try {
            http.newCall(r).execute()
        } catch (e: Exception) {
            throw IOException("Couldn't reach the server. Check the address and your connection.")
        }
        if (!resp.isSuccessful) {
            val code = resp.code
            resp.close()
            throw IOException(
                when (code) {
                    401, 403 -> "Wrong username or password."
                    404 -> "That folder doesn't exist on the server."
                    405 -> "The server doesn't allow this action."
                    else -> "The server returned error $code."
                }
            )
        }
        return resp
    }

    override fun child(dir: String, name: String) = (if (dir.endsWith("/")) dir else "$dir/") + Uri.encode(name)

    override fun list(path: String): List<RemoteEntry> {
        val body = """<?xml version="1.0" encoding="utf-8"?><d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/><d:getcontentlength/><d:getlastmodified/></d:prop></d:propfind>"""
            .toRequestBody("application/xml; charset=utf-8".toMediaType())
        val xml = exec(req(path).method("PROPFIND", body).header("Depth", "1").build()).use { it.body?.string() ?: "" }
        return sortRemote(parse(xml, path))
    }

    private fun parse(xml: String, self: String): List<RemoteEntry> {
        val out = ArrayList<RemoteEntry>()
        val p = XmlPullParserFactory.newInstance().apply { isNamespaceAware = true }.newPullParser()
        p.setInput(StringReader(xml))
        var href: String? = null
        var isCol = false
        var len = 0L
        var mod = 0L
        val text = StringBuilder()
        val df = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
        val selfNorm = Uri.decode(self).trimEnd('/')
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    when (p.name) {
                        "response" -> {
                            href = null; isCol = false; len = 0L; mod = 0L
                        }
                        "collection" -> isCol = true
                    }
                    text.setLength(0)
                }
                XmlPullParser.TEXT -> text.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "href" -> if (href == null) href = text.toString().trim()
                    "getcontentlength" -> len = text.toString().trim().toLongOrNull() ?: 0L
                    "getlastmodified" -> mod = runCatching { df.parse(text.toString().trim())?.time ?: 0L }.getOrDefault(0L)
                    "response" -> {
                        var h = href
                        if (h != null) {
                            if (h.startsWith("http://") || h.startsWith("https://")) h = runCatching { h!!.toHttpUrl().encodedPath }.getOrDefault(h)
                            val hp = h!!
                            if (Uri.decode(hp).trimEnd('/') != selfNorm) {
                                val name = Uri.decode(hp.trimEnd('/').substringAfterLast('/'))
                                val path = if (isCol && !hp.endsWith("/")) "$hp/" else hp
                                if (name.isNotEmpty()) out += RemoteEntry(name, path, isCol, len, mod)
                            }
                        }
                    }
                }
            }
            ev = p.next()
        }
        return out
    }

    override fun download(entry: RemoteEntry, dest: File) {
        exec(req(entry.path).get().build()).use { r ->
            val b = r.body ?: throw IOException("The server sent an empty file.")
            b.byteStream().use { ins -> FileOutputStream(dest).use { ins.copyTo(it, 64 * 1024) } }
        }
    }

    override fun uploadFile(local: File, dir: String) {
        exec(req(child(dir, local.name)).put(local.asRequestBody("application/octet-stream".toMediaType())).build()).close()
    }

    override fun mkdir(dir: String, name: String): String {
        val p = child(dir, name) + "/"
        exec(req(p).method("MKCOL", null).build()).close()
        return p
    }

    override fun delete(entry: RemoteEntry) {
        exec(req(entry.path).delete().build()).close()
    }

    override fun close() {
        http.dispatcher.executorService.shutdown()
        http.connectionPool.evictAll()
    }
}
