package com.jash.files.data

import java.io.File

enum class FileKind { Folder, Image, Video, Audio, Pdf, Doc, Sheet, Slides, Text, Archive, Apk, Code, Other }

enum class SortMode(val title: String) { Name("Name"), Date("Date"), Size("Size"), Kind("Kind") }

enum class FileCategory(val title: String, val exts: Set<String>) {
    Images("Images", setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")),
    Videos("Videos", setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v")),
    Audio("Audio", setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr")),
    Documents(
        "Documents",
        setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "ods", "odp", "csv", "md", "epub")
    ),
    Archives("Archives", setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz")),
    Apps("APKs", setOf("apk", "apks", "xapk"));

    companion object {
        fun of(ext: String): FileCategory? = entries.firstOrNull { ext in it.exts }
    }
}

private val docExts = setOf("doc", "docx", "odt", "rtf", "pages")
private val sheetExts = setOf("xls", "xlsx", "ods", "csv", "numbers")
private val slideExts = setOf("ppt", "pptx", "odp", "key")
private val textExts = setOf("txt", "md", "log", "ini", "cfg", "conf")
private val codeExts = setOf(
    "html", "htm", "css", "js", "json", "xml", "kt", "java", "py", "c", "cpp", "h", "sh", "ts", "yml", "yaml"
)

fun kindOf(ext: String, isDir: Boolean): FileKind = when {
    isDir -> FileKind.Folder
    ext in FileCategory.Images.exts -> FileKind.Image
    ext in FileCategory.Videos.exts -> FileKind.Video
    ext in FileCategory.Audio.exts -> FileKind.Audio
    ext == "pdf" -> FileKind.Pdf
    ext in docExts -> FileKind.Doc
    ext in sheetExts -> FileKind.Sheet
    ext in slideExts -> FileKind.Slides
    ext in textExts -> FileKind.Text
    ext in FileCategory.Archives.exts -> FileKind.Archive
    ext in FileCategory.Apps.exts -> FileKind.Apk
    ext in codeExts -> FileKind.Code
    else -> FileKind.Other
}

data class FileItem(
    val file: File,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val childCount: Int,
) {
    val name: String get() = file.name
    val path: String get() = file.absolutePath
    val ext: String get() = if (isDir) "" else file.extension.lowercase()
    val kind: FileKind get() = kindOf(ext, isDir)
}

fun kindName(item: FileItem): String {
    val e = item.ext.uppercase()
    return when (item.kind) {
        FileKind.Folder -> "Folder"
        FileKind.Image -> "$e Image"
        FileKind.Video -> "$e Video"
        FileKind.Audio -> "$e Audio"
        FileKind.Pdf -> "PDF Document"
        FileKind.Doc -> "$e Document"
        FileKind.Sheet -> "$e Spreadsheet"
        FileKind.Slides -> "$e Presentation"
        FileKind.Text -> "Plain Text"
        FileKind.Archive -> "$e Archive"
        FileKind.Apk -> "Android App"
        FileKind.Code -> "$e Source"
        FileKind.Other -> if (e.isEmpty()) "Document" else "$e File"
    }
}

data class StorageStats(
    val total: Long,
    val free: Long,
    val byCategory: Map<FileCategory, Long>,
    val large: List<FileItem>,
) {
    val used: Long get() = (total - free).coerceAtLeast(0)
    val categorized: Long get() = byCategory.values.sum()
    val other: Long get() = (used - categorized).coerceAtLeast(0)
}

// ---------- Version 2 models ----------

enum class ServerType(val title: String, val defaultPort: Int) {
    FTP("FTP", 21),
    SMB("LAN", 445),
    WEBDAV("WebDAV", 443),
}

data class Server(
    val id: String,
    val type: ServerType,
    val name: String,
    val host: String,
    val port: Int,
    val user: String,
    val pass: String,
    /** FTP: start folder · SMB: share name · WebDAV: full URL */
    val path: String,
) {
    val subtitle: String
        get() = when (type) {
            ServerType.FTP -> "ftp://$host" + (if (port != 21 && port > 0) ":$port" else "")
            ServerType.SMB -> "\\\\$host\\$path"
            ServerType.WEBDAV -> path
        }

    fun toJson(): org.json.JSONObject = org.json.JSONObject()
        .put("id", id).put("type", type.name).put("name", name).put("host", host)
        .put("port", port).put("user", user).put("pass", pass).put("path", path)

    companion object {
        fun fromJson(o: org.json.JSONObject) = Server(
            id = o.optString("id"),
            type = runCatching { ServerType.valueOf(o.optString("type")) }.getOrDefault(ServerType.FTP),
            name = o.optString("name"),
            host = o.optString("host"),
            port = o.optInt("port", 0),
            user = o.optString("user"),
            pass = o.optString("pass"),
            path = o.optString("path"),
        )
    }
}

data class RemoteEntry(
    val name: String,
    val path: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
) {
    /** A stand-in local item so the shared icon views can draw it. */
    fun asItem(): FileItem = FileItem(File(name), isDir, size, modified, 0)
}

data class TrashItem(
    val file: File,
    val originalPath: String,
    val deletedAt: Long,
) {
    val name: String get() = originalPath.substringAfterLast('/')
    val isDir: Boolean get() = file.isDirectory
    fun asItem(): FileItem = FileItem(file, isDir, if (isDir) 0L else file.length(), deletedAt, 0)
}

data class VaultItem(
    val file: File,
    val originalPath: String,
    val size: Long,
    val added: Long,
) {
    val name: String get() = originalPath.substringAfterLast('/')
    fun asItem(): FileItem = FileItem(File(name), false, size, added, 0)
}

data class JunkGroup(
    val id: String,
    val title: String,
    val subtitle: String,
    val files: List<File>,
    val size: Long,
    val autoClean: Boolean,
)
