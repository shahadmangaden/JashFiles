package com.jash.files.data

import android.content.Context
import android.util.Base64
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

// =====================================================================
// Recycle Bin
// =====================================================================

/** Deleted items are moved to /storage/emulated/0/.JashTrash and listed in a small index file. */
object Trash {
    val dir: File get() = File(FileRepo.root, ".JashTrash")
    private val index: File get() = File(dir, ".index")

    private data class Entry(val stored: String, val original: String, val at: Long)

    private fun readIndex(): List<Entry> {
        if (!index.exists()) return emptyList()
        return index.readLines().mapNotNull { line ->
            val parts = line.split('\t')
            if (parts.size < 3) null else Entry(parts[0], parts[1], parts[2].toLongOrNull() ?: 0L)
        }
    }

    private fun writeIndex(entries: List<Entry>) {
        dir.mkdirs()
        index.writeText(entries.joinToString("") { "${it.stored}\t${it.original}\t${it.at}\n" })
    }

    fun isInside(f: File): Boolean {
        val d = dir.absolutePath
        return f.absolutePath == d || f.absolutePath.startsWith("$d/")
    }

    fun items(): List<TrashItem> = readIndex()
        .map { TrashItem(File(dir, it.stored), it.original, it.at) }
        .filter { it.file.exists() }
        .sortedByDescending { it.deletedAt }

    fun totalSize(): Long = items().sumOf { if (it.file.isDirectory) FileRepo.folderSize(it.file) else it.file.length() }

    fun moveToTrash(files: List<File>) {
        dir.mkdirs()
        File(dir, ".nomedia").apply { if (!exists()) createNewFile() }
        val entries = readIndex().toMutableList()
        for (f in files) {
            if (!f.exists()) continue
            val stored = "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}_${f.name}"
            val target = File(dir, stored)
            if (!f.renameTo(target)) {
                if (!f.copyRecursively(target, overwrite = false)) throw IOException("Couldn't move “${f.name}” to the Recycle Bin.")
                f.deleteRecursively()
            }
            entries += Entry(stored, f.absolutePath, System.currentTimeMillis())
        }
        writeIndex(entries)
    }

    fun restore(items: List<TrashItem>) {
        val names = items.map { it.file.name }.toSet()
        for (it in items) {
            val original = File(it.originalPath)
            val parent = original.parentFile ?: FileRepo.root
            parent.mkdirs()
            val target = FileRepo.uniqueTarget(parent, original.name, it.file.isDirectory)
            if (!it.file.renameTo(target)) {
                if (!it.file.copyRecursively(target, overwrite = false)) throw IOException("Couldn't restore “${it.name}”.")
                it.file.deleteRecursively()
            }
        }
        writeIndex(readIndex().filter { it.stored !in names })
    }

    fun deleteForever(items: List<TrashItem>) {
        val names = items.map { it.file.name }.toSet()
        items.forEach { it.file.deleteRecursively() }
        writeIndex(readIndex().filter { it.stored !in names })
    }

    fun empty() {
        deleteForever(items())
        dir.listFiles()?.filter { it.name != ".index" && it.name != ".nomedia" }?.forEach { it.deleteRecursively() }
    }
}

// =====================================================================
// Encrypted folder (vault)
// =====================================================================

/**
 * Files are encrypted with AES-256 (CTR) and authenticated with HMAC-SHA256.
 * The key is derived from the password with PBKDF2 and only kept in memory while unlocked.
 *
 * File layout: "JV01" | metaIv(16) | metaLen(int) | meta | dataIv(16) | data... | hmac(32)
 */
object Vault {
    val dir: File get() = File(FileRepo.root, ".JashVault")
    private const val MAGIC = "JV01"
    private const val ITERATIONS = 120_000
    private var encKey: ByteArray? = null
    private var macKey: ByteArray? = null

    val isUnlocked: Boolean get() = encKey != null

    fun isInside(f: File): Boolean {
        val d = dir.absolutePath
        return f.absolutePath == d || f.absolutePath.startsWith("$d/")
    }

    private fun derive(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 512)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray =
        Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(key, "HmacSHA256")) }.doFinal(data)

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    fun isSetUp(prefs: Prefs) = prefs.vaultSalt != null && prefs.vaultCheck != null

    fun setUp(prefs: Prefs, password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val k = derive(password, salt)
        prefs.vaultSalt = b64(salt)
        prefs.vaultCheck = b64(hmac(k.copyOfRange(32, 64), "jash-vault-check".toByteArray()))
        encKey = k.copyOfRange(0, 32)
        macKey = k.copyOfRange(32, 64)
        dir.mkdirs()
        File(dir, ".nomedia").apply { if (!exists()) createNewFile() }
    }

    fun unlock(prefs: Prefs, password: String): Boolean {
        val salt = prefs.vaultSalt ?: return false
        val check = prefs.vaultCheck ?: return false
        val k = derive(password, unb64(salt))
        val ok = MessageDigest.isEqual(hmac(k.copyOfRange(32, 64), "jash-vault-check".toByteArray()), unb64(check))
        if (ok) {
            encKey = k.copyOfRange(0, 32)
            macKey = k.copyOfRange(32, 64)
        }
        return ok
    }

    fun lock() {
        encKey?.fill(0)
        macKey?.fill(0)
        encKey = null
        macKey = null
    }

    private fun keys(): Pair<ByteArray, ByteArray> {
        val e = encKey ?: throw IOException("The encrypted folder is locked.")
        val m = macKey ?: throw IOException("The encrypted folder is locked.")
        return e to m
    }

    private fun ctr(mode: Int, key: ByteArray, iv: ByteArray): Cipher =
        Cipher.getInstance("AES/CTR/NoPadding").apply { init(mode, SecretKeySpec(key, "AES"), IvParameterSpec(iv)) }

    /** Encrypts [input] into the vault, remembering [originalPath]. */
    fun addStream(input: InputStream, originalPath: String) {
        val (ek, mk) = keys()
        dir.mkdirs()
        File(dir, ".nomedia").apply { if (!exists()) createNewFile() }
        val out = File(dir, UUID.randomUUID().toString() + ".jv")
        val rnd = SecureRandom()
        val metaIv = ByteArray(16).also { rnd.nextBytes(it) }
        val dataIv = ByteArray(16).also { rnd.nextBytes(it) }
        val meta = ctr(Cipher.ENCRYPT_MODE, ek, metaIv).doFinal("$originalPath\n${System.currentTimeMillis()}".toByteArray())
        val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(mk, "HmacSHA256")) }
        try {
            DataOutputStream(FileOutputStream(out).buffered()).use { os ->
                fun w(b: ByteArray) {
                    os.write(b)
                    mac.update(b)
                }
                w(MAGIC.toByteArray())
                w(metaIv)
                val len = java.nio.ByteBuffer.allocate(4).putInt(meta.size).array()
                w(len)
                w(meta)
                w(dataIv)
                val c = ctr(Cipher.ENCRYPT_MODE, ek, dataIv)
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    val enc = c.update(buf, 0, n)
                    if (enc != null) w(enc)
                }
                c.doFinal()?.let { if (it.isNotEmpty()) w(it) }
                os.write(mac.doFinal())
            }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
    }

    /** Moves local files (and folder contents) into the vault, deleting the originals. */
    fun addFiles(files: List<File>) {
        for (f in files) {
            val all = if (f.isDirectory) f.walkTopDown().filter { it.isFile }.toList() else listOf(f)
            for (x in all) {
                x.inputStream().use { addStream(it, x.absolutePath) }
                x.delete()
            }
            if (f.isDirectory) f.deleteRecursively()
        }
    }

    private fun readMeta(f: File, ek: ByteArray): Pair<String, Long>? = try {
        DataInputStream(FileInputStream(f).buffered()).use { ins ->
            val magic = ByteArray(4).also { ins.readFully(it) }
            if (String(magic) != MAGIC) return null
            val metaIv = ByteArray(16).also { ins.readFully(it) }
            val len = ins.readInt()
            if (len <= 0 || len > 64 * 1024) return null
            val meta = ByteArray(len).also { ins.readFully(it) }
            val text = String(ctr(Cipher.DECRYPT_MODE, ek, metaIv).doFinal(meta))
            text.substringBefore('\n') to (text.substringAfter('\n', "0").toLongOrNull() ?: f.lastModified())
        }
    } catch (e: Exception) {
        null
    }

    fun items(): List<VaultItem> {
        val (ek, _) = keys()
        return (dir.listFiles() ?: emptyArray())
            .filter { it.isFile && it.name.endsWith(".jv") }
            .mapNotNull { f ->
                readMeta(f, ek)?.let { (path, added) ->
                    val headerGuess = 4 + 16 + 4 + 16 + 32
                    VaultItem(f, path, (f.length() - headerGuess - path.length - 16).coerceAtLeast(0), added)
                }
            }
            .sortedByDescending { it.added }
    }

    /** Verifies and decrypts [item] into [dest]. */
    fun decryptTo(item: VaultItem, dest: File) {
        val (ek, mk) = keys()
        val f = item.file
        val total = f.length()
        if (total < 4 + 16 + 4 + 16 + 32) throw IOException("This encrypted file is damaged.")
        // Pass 1: check the HMAC so tampered files are never decrypted.
        val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(mk, "HmacSHA256")) }
        val expected = ByteArray(32)
        FileInputStream(f).buffered().use { ins ->
            var left = total - 32
            val buf = ByteArray(64 * 1024)
            while (left > 0) {
                val n = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) throw IOException("This encrypted file is damaged.")
                mac.update(buf, 0, n)
                left -= n
            }
            DataInputStream(ins).readFully(expected)
        }
        if (!MessageDigest.isEqual(mac.doFinal(), expected)) throw IOException("This encrypted file is damaged or was changed.")
        // Pass 2: decrypt.
        DataInputStream(FileInputStream(f).buffered()).use { ins ->
            ins.skipBytes(4 + 16)
            val metaLen = ins.readInt()
            ins.skipBytes(metaLen)
            val dataIv = ByteArray(16).also { ins.readFully(it) }
            val dataLen = total - 4 - 16 - 4 - metaLen - 16 - 32
            val limited = object : InputStream() {
                var left = dataLen
                override fun read(): Int = if (left <= 0) -1 else ins.read().also { if (it >= 0) left-- }
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    if (left <= 0) return -1
                    val n = ins.read(b, off, minOf(len.toLong(), left).toInt())
                    if (n > 0) left -= n
                    return n
                }
            }
            dest.parentFile?.mkdirs()
            CipherInputStream(limited, ctr(Cipher.DECRYPT_MODE, ek, dataIv)).use { cis ->
                FileOutputStream(dest).use { cis.copyTo(it, 64 * 1024) }
            }
        }
    }

    /** Decrypts back to the original location (or a free name next to it) and removes it from the vault. */
    fun restore(item: VaultItem): File {
        val original = File(item.originalPath)
        val parent = original.parentFile?.takeIf { it.exists() || it.mkdirs() } ?: File(FileRepo.root, "Download")
        val target = FileRepo.uniqueTarget(parent, original.name, false)
        decryptTo(item, target)
        item.file.delete()
        return target
    }

    fun delete(items: List<VaultItem>) {
        items.forEach { it.file.delete() }
    }
}

// =====================================================================
// Cleanup
// =====================================================================

object Cleaner {
    private val tempExts = setOf("tmp", "temp", "log", "dmp", "crdownload", "part", "partial")

    fun scan(ctx: Context): List<JunkGroup> {
        val root = FileRepo.root
        val rootPath = root.absolutePath
        val skip = setOf("$rootPath/Android", Trash.dir.absolutePath, Vault.dir.absolutePath)
        val thumbs = ArrayList<File>()
        val temps = ArrayList<File>()
        val apks = ArrayList<File>()
        val empties = ArrayList<File>()

        root.walkTopDown()
            .onEnter { d ->
                if (d.absolutePath in skip) return@onEnter false
                if (d.name == ".thumbnails") {
                    thumbs.add(d)
                    return@onEnter false
                }
                true
            }
            .forEach { f ->
                if (f.isFile) {
                    val e = f.extension.lowercase()
                    if (e in tempExts) temps.add(f)
                    else if (e == "apk") apks.add(f)
                } else if (f.isDirectory && f.parentFile?.absolutePath != rootPath && f.absolutePath != rootPath) {
                    val kids = f.list()
                    if (kids != null && kids.isEmpty()) empties.add(f)
                }
            }

        val caches = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)
            .flatMap { it.listFiles()?.toList() ?: emptyList() }

        fun size(list: List<File>) = list.sumOf { if (it.isDirectory) FileRepo.folderSize(it) else it.length() }

        return listOf(
            JunkGroup("thumbs", "Thumbnail Caches", "Preview images the system can rebuild", thumbs, size(thumbs), true),
            JunkGroup("temp", "Temporary & Log Files", "Unfinished downloads, .tmp and .log files", temps, size(temps), true),
            JunkGroup("cache", "Jash Files Cache", "Files this app saved while opening items", caches, size(caches), true),
            JunkGroup("empty", "Empty Folders", "Folders with nothing inside", empties, 0L, true),
            JunkGroup("apk", "Installation Files", "APK files you may no longer need", apks, size(apks), false),
        ).filter { it.files.isNotEmpty() }
    }

    /** Deletes the groups' files and returns the bytes freed. */
    fun clean(groups: List<JunkGroup>): Long {
        var freed = 0L
        for (g in groups) for (f in g.files) {
            val s = if (f.isDirectory) FileRepo.folderSize(f) else f.length()
            if (f.deleteRecursively()) freed += s
        }
        return freed
    }
}
