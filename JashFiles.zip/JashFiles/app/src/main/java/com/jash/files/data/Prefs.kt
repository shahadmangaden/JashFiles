package com.jash.files.data

import android.content.Context
import java.io.File

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("jash_files", Context.MODE_PRIVATE)

    var sort: SortMode
        get() = runCatching { SortMode.valueOf(p.getString("sort", "Name")!!) }.getOrDefault(SortMode.Name)
        set(v) = p.edit().putString("sort", v.name).apply()

    var sortAsc: Boolean
        get() = p.getBoolean("sortAsc", true)
        set(v) = p.edit().putBoolean("sortAsc", v).apply()

    var grid: Boolean
        get() = p.getBoolean("grid", false)
        set(v) = p.edit().putBoolean("grid", v).apply()

    var showHidden: Boolean
        get() = p.getBoolean("hidden", false)
        set(v) = p.edit().putBoolean("hidden", v).apply()

    /** 0 = automatic, 1 = light, 2 = dark */
    var theme: Int
        get() = p.getInt("theme", 0)
        set(v) = p.edit().putInt("theme", v).apply()

    var confirmDelete: Boolean
        get() = p.getBoolean("confirmDelete", true)
        set(v) = p.edit().putBoolean("confirmDelete", v).apply()

    fun favorites(root: File): List<String> {
        val s = p.getString("favs", null) ?: return defaultFavorites(root)
        return s.split('\n').filter { it.isNotBlank() }
    }

    fun defaultFavorites(root: File): List<String> =
        listOf("Download", "Documents", "DCIM", "Pictures").map { File(root, it).absolutePath }

    fun setFavorites(list: List<String>) = p.edit().putString("favs", list.joinToString("\n")).apply()

    // ---------- Version 2 ----------

    var useTrash: Boolean
        get() = p.getBoolean("useTrash", true)
        set(v) = p.edit().putBoolean("useTrash", v).apply()

    var ignoreNomedia: Boolean
        get() = p.getBoolean("ignoreNomedia", false)
        set(v) = p.edit().putBoolean("ignoreNomedia", v).apply()

    var autoClean: Boolean
        get() = p.getBoolean("autoClean", false)
        set(v) = p.edit().putBoolean("autoClean", v).apply()

    var lastClean: Long
        get() = p.getLong("lastClean", 0L)
        set(v) = p.edit().putLong("lastClean", v).apply()

    var vaultSalt: String?
        get() = p.getString("vaultSalt", null)
        set(v) = p.edit().putString("vaultSalt", v).apply()

    var vaultCheck: String?
        get() = p.getString("vaultCheck", null)
        set(v) = p.edit().putString("vaultCheck", v).apply()

    fun servers(): List<Server> = runCatching {
        val arr = org.json.JSONArray(p.getString("servers", "[]"))
        (0 until arr.length()).map { Server.fromJson(arr.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun setServers(list: List<Server>) {
        val arr = org.json.JSONArray()
        list.forEach { arr.put(it.toJson()) }
        p.edit().putString("servers", arr.toString()).apply()
    }
}
