plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.jash.files"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jash.files"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    signingConfigs {
        create("jash") {
            // One fixed key so every build (phone, GitHub, Android Studio) can update the installed app.
            storeFile = file("jash.keystore")
            storePassword = "jashfiles"
            keyAlias = "jash"
            keyPassword = "jashfiles"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("jash")
        }
        release {
            isMinifyEnabled = false
            // Signed with the debug key so the release APK installs directly.
            // Replace with your own keystore before publishing to a store.
            signingConfig = signingConfigs.getByName("jash")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/INDEX.LIST",
                "META-INF/versions/9/OSGI-INF/MANIFEST.MF",
                "META-INF/*.md",
            )
        }
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Network features
    implementation("commons-net:commons-net:3.11.1")      // FTP
    implementation("org.nanohttpd:nanohttpd:2.3.1")       // View on PC
    implementation("com.hierynomus:smbj:0.13.0")          // LAN (SMB)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")  // WebDAV
}
